# 🚀 Deployment auf Netcup Webhosting

## 📦 Schritt 1: Dateien hochladen

1. Entpacke das ZIP-Archiv auf deinem lokalen Rechner
2. Verbinde dich per FTP/SFTP zu deinem Netcup Webspace
3. Lade den kompletten `pca-app` Ordner in dein Webspace-Verzeichnis hoch

**Beispiel-Pfad auf Netcup:**
```
/is/htdocs/wp12345678/www/pca-app/
```

## ⚙️ Schritt 2: Konfiguration anpassen

### 2.1 `.htaccess` bearbeiten

Öffne die Datei `.htaccess` und ersetze die Platzhalter:

```apache
# Ändere diese Zeile:
PassengerAppRoot /CHANGE-THIS-TO-YOUR-ACTUAL-PATH/pca-app

# Beispiel:
PassengerAppRoot /is/htdocs/wp12345678/www/pca-app
```

```apache
# Ändere auch diese Zeile:
SetEnv PYTHONPATH /CHANGE-THIS-TO-YOUR-ACTUAL-PATH/pca-app

# Beispiel:
SetEnv PYTHONPATH /is/htdocs/wp12345678/www/pca-app
```

```apache
# Ändere den Secret Key:
SetEnv FLASK_SECRET_KEY CHANGE-THIS-TO-A-RANDOM-SECRET-KEY

# Generiere einen zufälligen Key (z.B. mit Python):
# python -c "import secrets; print(secrets.token_hex(32))"
```

### 2.2 `.env` bearbeiten (optional)

Die `.env` Datei ist bereits vorkonfiguriert für Produktion.
Du kannst optional folgende Werte anpassen:

- `FLASK_SECRET_KEY` - Ändern zu einem zufälligen Wert
- `DEMO_MODE` - Auf `true` setzen für Demo-Modus
- `LOG_LEVEL` - `DEBUG` für ausführliche Logs, `INFO` für Produktion

## 🐍 Schritt 3: Python-Umgebung einrichten

### Im Netcup WebCP (Webhosting Control Panel):

1. Gehe zu **Python Apps** oder **Passenger**
2. Klicke auf **Neue Python-Anwendung erstellen**
3. Konfiguriere folgende Einstellungen:
   - **App Root:** `pca-app` (oder dein Ordnername)
   - **Startup File:** `passenger_wsgi.py`
   - **Python Version:** `3.9` oder höher
   - **Environment:** `production`

### Python-Pakete installieren:

Verbinde dich per SSH zu deinem Webspace und führe aus:

```bash
cd /pfad/zu/pca-app
pip3 install --user -r requirements.txt
```

**Oder** im WebCP unter "Python Apps":
- Klicke auf deine App
- Gehe zu "Pakete"
- Klicke auf "Aus requirements.txt installieren"

## 🔄 Schritt 4: Anwendung starten

### Im WebCP:

1. Gehe zu deiner Python-App
2. Klicke auf **"Anwendung neu starten"**

### Per SSH:

```bash
touch tmp/restart.txt
```

## ✅ Schritt 5: Testen

Öffne deine Domain im Browser:
```
https://deine-domain.de
```

Du solltest die PCA Yield Curve Stress Testing Webapp sehen!

## 🔧 Troubleshooting

### Problem: 500 Internal Server Error

**Lösung:**
- Prüfe die Pfade in `.htaccess` (PassengerAppRoot und PYTHONPATH)
- Stelle sicher, dass alle Python-Pakete installiert sind
- Prüfe die Logs: `/is/htdocs/wp12345678/logs/error_log`

### Problem: Keine Daten / ECB API Fehler

**Lösung:**
- Setze `DEMO_MODE=true` in `.env` oder `.htaccess` für Demo-Daten
- Prüfe, ob der Server ausgehende HTTPS-Verbindungen zulässt
- Erhöhe `ECB_API_TIMEOUT` auf 60 Sekunden

### Problem: Python-Pakete nicht gefunden

**Lösung:**
```bash
pip3 install --user -r requirements.txt
# oder für spezifische Pakete:
pip3 install --user flask pandas numpy scikit-learn
```

### Problem: Permission Errors

**Lösung:**
```bash
chmod 755 passenger_wsgi.py
chmod 755 app.py
chmod -R 755 services/
chmod -R 755 static/
chmod -R 755 templates/
```

## 📊 Wichtige Dateien und Ordner

```
pca-app/
├── .htaccess                 # Apache/Passenger Konfiguration (ANPASSEN!)
├── .env                      # Umgebungsvariablen (SECRET_KEY anpassen!)
├── passenger_wsgi.py         # WSGI Entry Point
├── app.py                    # Flask Hauptanwendung
├── config.py                 # App-Konfiguration
├── requirements.txt          # Python-Abhängigkeiten
├── services/                 # Backend-Services
├── templates/                # HTML-Templates (mit Dokumentation!)
├── static/                   # CSS, JavaScript
├── demo_data/                # Sample-Daten für Demo-Modus
└── tmp/                      # Für Passenger (restart.txt)
```

## 🔐 Sicherheitshinweise

1. ✅ **Ändere unbedingt den `FLASK_SECRET_KEY`** in `.htaccess` oder `.env`
2. ✅ Setze `FLASK_DEBUG=false` für Produktion
3. ✅ Aktiviere HTTPS (SSL-Zertifikat über Netcup)
4. ✅ Uncomment die HTTPS-Redirect-Zeilen in `.htaccess`:
   ```apache
   RewriteCond %{HTTPS} !=on
   RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
   ```

## 📞 Support

Bei Problemen:
1. Prüfe die Error Logs in `/is/htdocs/wp12345678/logs/`
2. Aktiviere Debug-Logging: `SetEnv LOG_LEVEL DEBUG` in `.htaccess`
3. Kontaktiere Netcup Support für Server-spezifische Probleme

## 🎉 Fertig!

Deine PCA Yield Curve Webapp ist jetzt live auf Netcup! 🚀

Die Webapp enthält jetzt auch eine ausführliche Dokumentation, die über den
Button "📖 Dokumentation & Methodologie" aufgerufen werden kann.
